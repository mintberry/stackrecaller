using System;
using System.Collections.Generic;
using System.Text;

namespace DDW
{
    /// <summary>
    /// Acts as a tag to indicate that a type may be pointer
    /// </summary>
	public interface IPointer
	{
	}
}
