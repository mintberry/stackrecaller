using System;
using System.Collections.Generic;
using System.Text;

namespace DDW
{
	public enum IntegralType
	{
		SByte,
		Byte,
		Short,
		UShort,
		Int,
		UInt,
		Long,
		ULong,
		Char,
	}
}
