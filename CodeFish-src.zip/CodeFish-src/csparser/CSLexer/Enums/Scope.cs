using System;
using System.Collections.Generic;
using System.Text;

namespace DDW.Enums
{
    public enum Scope
    {
        Static,
        Instance
    }
}
