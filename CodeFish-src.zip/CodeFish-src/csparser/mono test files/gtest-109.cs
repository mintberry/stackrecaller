using System;

class X {
	static void Main ()
	{
		int [] foo = null;
		Array.Resize (ref foo, 10);
	}
}
