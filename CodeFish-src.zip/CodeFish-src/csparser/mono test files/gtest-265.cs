// Compiler options: -r:gtest-265-lib.dll

class Test
{
        public static void Main ()
        {
                A x = new A ();
                x.Whoa<int> (null);
        }
}
