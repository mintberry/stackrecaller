// Compiler options: -t:library -unsafe

public unsafe struct ExternalStruct
{
    public fixed double double_buffer [4];
}
