// Compiler options: -t:library

namespace Foo
{
	public class List
	{
	}
}

namespace Bar
{
	public class List<T>
	{
	}
}
