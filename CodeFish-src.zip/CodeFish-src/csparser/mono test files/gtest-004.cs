class Stack<T> {
}

class Test {
}

class T {
	public void Foo (Stack<Test> a)
	{ }

	static void Main()
	{
	}
}
