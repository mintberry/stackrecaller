class Stack<T> : X
{
}

class Test
{
}

class X
{
	static void Main()
	{
	}
}
