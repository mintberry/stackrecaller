public class LinkedList<T>
{
	protected class Node
	{ }
}

public class HashedLinkedList<T> : LinkedList<T>
{
	Node node;
}

class X
{
	static void Main ()
	{ }
}
