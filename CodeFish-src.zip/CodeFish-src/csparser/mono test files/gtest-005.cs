class Stack<T> {
}

class Test {
}

class T {
	static void Main()
	{
		Stack<Test> a;
	}
}
