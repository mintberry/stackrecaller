// Compiler options: -r:gtest-013-lib.dll

public class X
{
	Stack<int> stack;

	void Test ()
	{
		stack.Hello (3);
	}

	static void Main ()
	{ }
}
