// Compiler options: /r:gtest-172-lib.dll
class M {
  static void Main () {
    A <int> x = A<int>.Nil._N_constant_object; 
  }
}

