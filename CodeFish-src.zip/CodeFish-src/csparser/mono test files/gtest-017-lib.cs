// Compiler options: -t:library

public class Stack
{
	public Stack ()
	{ }

	public void Hello<T> (T t)
	{ }
}
