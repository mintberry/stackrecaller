using System;

public class Tests
{
	public static void Main ()
	{
		int? dummy = null;

		Console.WriteLine ("Hello: " + dummy);
	}
}
