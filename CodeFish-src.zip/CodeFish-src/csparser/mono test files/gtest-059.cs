namespace N {
	interface A <T> {
	}
}
class X <T> : N.A <T> {
}
class Foo {
	static void Main () {}
}
