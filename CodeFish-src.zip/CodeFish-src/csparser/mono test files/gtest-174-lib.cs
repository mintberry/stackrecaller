// Compiler options: -t:library
public class A <T> {
	public static A<T> _N_constant_object = new A<T> ();
}
