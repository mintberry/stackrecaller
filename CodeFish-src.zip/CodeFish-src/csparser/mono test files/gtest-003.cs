class Stack<T> {
}

class Test {
}

class T {
	Stack<Test> a;

	static void Main()
	{
	}
}
