public interface Foo
{
	T Test<T> ()
		where T : class;
}

class X
{
	static void Main ()
	{ }
}
