// Compiler options: -t:library

public class Stack<S>
{
	public void Hello (S s)
	{ }
}
