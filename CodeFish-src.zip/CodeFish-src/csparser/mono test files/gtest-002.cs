class Cell <X> {
	X value;

}

class D {
	static void Main ()
	{
	}
}
