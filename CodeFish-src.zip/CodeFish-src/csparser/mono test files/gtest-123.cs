class A<T>
{
	public delegate void Foo ();
	public delegate void Bar<U> ();
}

class X
{
	static void Main ()
	{ }
}
