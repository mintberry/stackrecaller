using System;

class X
{
	static void Main ()
	{
		int? a = 4;
		int? b = -a;
		Console.WriteLine (b);
	}
}
