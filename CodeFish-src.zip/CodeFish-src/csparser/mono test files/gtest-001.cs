class Stack < type > {

}

class Boot {
	static void Main ()
	{
	}
}
