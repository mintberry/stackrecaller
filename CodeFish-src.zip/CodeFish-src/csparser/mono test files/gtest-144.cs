using System;

namespace Test
{
	public class Application
	{
		public static void Main()
		{
			string[] array = new string[10];

			System.Collections.Generic.IEnumerable<string> enumer = array;
		}
	}
}
